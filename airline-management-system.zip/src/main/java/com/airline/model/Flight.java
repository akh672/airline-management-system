package com.airline.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Flight {

    @Id
    private String id;
    private String origin;
    private String destination;

    // Getters and setters
}
